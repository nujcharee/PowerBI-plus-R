module powerbi.visuals.plugins {
    export var custommap5A89ADFB5F694F71AB6D00C94383BB2B_DEBUG = {
        name: 'custommap5A89ADFB5F694F71AB6D00C94383BB2B_DEBUG',
        displayName: 'Custom Map',
        class: 'Visual',
        version: '1.0.0',
        apiVersion: '1.10.0',
        create: (options: extensibility.visual.VisualConstructorOptions) => new powerbi.extensibility.visual.custommap5A89ADFB5F694F71AB6D00C94383BB2B.Visual(options),
        custom: true
    };
}
